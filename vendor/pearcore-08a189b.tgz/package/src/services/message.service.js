import * as EVENTS from '../constants/events.constants.js';
import { isFunction } from '../utils/general.utils.js';
import { getSpaceTopicHash } from "../utils/space.utils.js"
import { createSpaceMessage, encryptPayload } from '../utils/protocol.utils.js';
import { publicKeyIsAllowedToRead } from '../utils/policy.utils.js';
import { encryptJSON, hex, randomNonce } from '../utils/crypto.utils.js';
import { SpaceInstance } from './space.service.js';
import { flushMessageRecord, queryMessageRecord } from '../utils/message.utils.js';

export class MessageService {
    constructor(emitter, { managers }) {
        this.emitter = emitter;
        this.managers = managers;

        // links: message nonce -> callback function
        this.nonceStack = new Map();
        this.emitter.on(EVENTS.Reject, (context) => {
            const nonce = context.linkedMessageNonce;
            const fn = this.nonceStack.get(nonce);

            if (fn) {
                try { fn(context); }
                catch(error) { console.error(error); } // avoid halt
            }
        })
    }

    get db() {
        return this.managers.session.getDatabase().db;
    }

    assignCallback(message, callback) {
        this.nonceStack.set(message.nonce, callback);
    }

    /**
     * Query message records using filters.
     *
     * @param {Object} filters - query filters (all optional)
     * @param {number} filters.id - exact ID match
     * @param {string} filters.type - exact type match
     * @param {string} filters.topic - exact topic match
     * @param {boolean} filters.isRelay - relay status (true/false)
     * @param {string} filters.senderPublicKey - sender's public key (exact match)
     * @param {Object} filters.broadcastTimestamp - broadcast timestamp range
     * @param {number} filters.broadcastTimestamp.start - start timestamp (inclusive)
     * @param {number} filters.broadcastTimestamp.end - end timestamp (inclusive)
     * @param {Object} filters.messageTimestamp - message timestamp range
     * @param {number} filters.messageTimestamp.start - start timestamp (inclusive)
     * @param {number} filters.messageTimestamp.end - end timestamp (inclusive)
     * @param {string} filters.nonce - exact nonce match
     * @param {string} filters.messageOwnerPublicKey - owner's public key (exact match)
     * @param {string} filters.signature - exact signature match
     * @param {string} filters.payloadContains - substring search in payload (case-insensitive)
     * @param {number} filters.limit - maximum records to return (default: 100, max: 1000)
     * @param {number} filters.offset - records to skip (default: 0)
     * @param {string} filters.orderBy - field to order by: 'messageTimestamp', 'broadcastTimestamp', or 'id' (default: 'messageTimestamp')
     * @param {string} filters.orderDirection - 'asc' for ascending, 'desc' for descending (default: 'desc')
     * @returns {Promise<Array<Object>>} Array of message records
     */
    async list(filters = {}) {
        const messages = await queryMessageRecord(this.db, filters);
        return messages;
    }

    /**
     * Delete message records using filters.
     *
     * @param {Object} filters - query filters (all optional)
     * @param {number} filters.id - exact ID match
     * @param {string} filters.type - exact type match
     * @param {string} filters.topic - exact topic match
     * @param {boolean} filters.isRelay - relay status (true/false)
     * @param {string} filters.senderPublicKey - sender's public key (exact match)
     * @param {Object} filters.broadcastTimestamp - broadcast timestamp range
     * @param {number} filters.broadcastTimestamp.start - start timestamp (inclusive)
     * @param {number} filters.broadcastTimestamp.end - end timestamp (inclusive)
     * @param {Object} filters.messageTimestamp - message timestamp range
     * @param {number} filters.messageTimestamp.start - start timestamp (inclusive)
     * @param {number} filters.messageTimestamp.end - end timestamp (inclusive)
     * @param {string} filters.nonce - exact nonce match
     * @param {string} filters.messageOwnerPublicKey - owner's public key (exact match)
     * @param {string} filters.signature - exact signature match
     * @param {string} filters.payloadContains - substring search in payload (case-insensitive)
     * @param {number} filters.limit - maximum records to return (default: 100, max: 1000)
     * @param {number} filters.offset - records to skip (default: 0)
     * @param {string} filters.orderBy - field to order by: 'messageTimestamp', 'broadcastTimestamp', or 'id' (default: 'messageTimestamp')
     * @param {string} filters.orderDirection - 'asc' for ascending, 'desc' for descending (default: 'desc')
     * @returns {Promise<Array<Object>>} Array of deleted message records
     */
    async flush(filters = {}) {
        return await flushMessageRecord(this.db, filters);
    }

    /**
     * Send a message to a space/topic.
     * 
     * @param {SpaceInstance} space - The space instance for message assignment.
     * @param {Object} payload - Message content
     * @param {CallableFunction} onRejectionCallback - callback function that will be called whenever sockets sends back rejection for the mesage
     * @returns {Promise<void>} Resolves when the message has been sent to the connected nodes.
     */
    async send(space, payload, onRejectionCallback = undefined) {
        const { publicKey, secretKey } = this.managers.session.getCredentials();

        const nonce = hex(randomNonce());
        if (space.secret) {
            payload = await encryptPayload({ payload, spaceSecret: space.secret, nonce: nonce });
        }

        const message = await createSpaceMessage({
            topic: space.topicHash,
            messagePayload: payload,
            publicKey: publicKey,
            secretKey: secretKey,
            nonce: nonce
        });

        // limit the nodes to a subset that has the required permission to receive this message
        const peers = this.managers.sockets.getPeerKeys(key => publicKeyIsAllowedToRead(key, space));
        const sockets = this.managers.sockets.getConnectedSockets({
            peers: peers, topics: [space.topicHash]
        });

        // assign the callback for the message
        // when core receives rejection message related to this message, it will be called.
        if (isFunction(onRejectionCallback)) {
            this.assignCallback(message, onRejectionCallback);
        }

        return await this.managers.message.broadcastMessageToSockets(message, sockets);
    }
}