import { test } from 'node:test'
import assert from 'node:assert/strict'
import { generate, consent, enroll, revoke, unban, Chain, fold, REENROLL_COOLDOWN } from '../src/index.js'

// master (cold, bip340 like a Nostr key) → warm steward on the phone → Vine app key
async function account () {
  const master = generate('bip340')
  const warm = generate('ed25519')
  const vine = generate('bip340')
  const chain = await Chain.create(master, { label: 'Guy' })
  const root = master.ref
  await chain.append(await enroll(master, { root, key: warm.ref, consent: await consent(warm, root), scope: ['bind', 'delegate'], label: 'phone' }), master)
  await chain.append(await enroll(warm, { root, key: vine.ref, consent: await consent(vine, root), label: 'Vine' }), warm)
  return { master, warm, vine, chain, root }
}

test('three-tier enrollment across suites', async () => {
  const { chain, warm, vine } = await account()
  assert.equal(chain.state.status(warm.ref), 'active')
  assert.equal(chain.state.status(vine.ref), 'active')
  assert.deepEqual(chain.state.ancestors(vine.ref), [warm.ref, chain.root])
  assert.equal(chain.state.can(vine.ref, 'delegate'), false)
  assert.equal(fold(chain.toJSON()).error, null)
})

test("can't add someone else's key without their consent", async () => {
  const { chain, warm, root } = await account()
  const brother = generate('bip340')
  const someoneElse = generate('bip340')
  // consent signed by a different key than the one being enrolled
  await assert.rejects(async () => await chain.append(await enroll(warm, { root, key: brother.ref, consent: await consent(someoneElse, root) }), warm), /consent/)
  // brother's consent to *his own* account doesn't transfer to ours
  const brothersRoot = generate('bip340').ref
  await assert.rejects(async () => await chain.append(await enroll(warm, { root, key: brother.ref, consent: await consent(brother, brothersRoot) }), warm), /consent/)
})

test('non-delegating key cannot enroll or write', async () => {
  const { chain, vine, root } = await account()
  const sub = generate()
  await assert.rejects(async () => await chain.append(await enroll(vine, { root, key: sub.ref, consent: await consent(sub, root) }), vine), /cannot delegate/)
})

test('scope cannot exceed parent', async () => {
  const { chain, warm, root } = await account()
  const k = generate()
  await assert.rejects(async () => await chain.append(await enroll(warm, { root, key: k.ref, consent: await consent(k, root), scope: ['bind', 'chat'] }), warm), /exceeds parent/)
})

test('app revokes itself; steward folds it in later, verifiers honor it immediately', async () => {
  const { chain, warm, vine, root } = await account()
  const leave = await revoke(vine, { root, key: vine.ref })
  const { state } = chain.view([leave])
  assert.equal(state.status(vine.ref), 'revoked')
  assert.equal(chain.state.status(vine.ref), 'active') // chain itself not yet updated
  await chain.append(leave, warm)
  assert.equal(chain.state.status(vine.ref), 'revoked')
})

test('revoking a delegating key orphans its subtree; re-adopting upward restores it', async () => {
  const { chain, master, warm, vine, root } = await account()
  await chain.append(await revoke(master, { root, key: warm.ref }), master)
  assert.equal(chain.state.status(warm.ref), 'revoked')
  assert.equal(chain.state.status(vine.ref), 'orphaned')
  assert.equal(chain.state.can(warm.ref, 'delegate'), false)

  // the same consent is reusable because it doesn't name the parent
  await chain.append(await enroll(master, { root, key: vine.ref, consent: await consent(vine, root), label: 'Vine' }), master)
  assert.equal(chain.state.status(vine.ref), 'active')
  assert.deepEqual(chain.state.ancestors(vine.ref), [root])
})

test('a removed key can come back after the cooldown with fresh consent; the gap stays untrusted', async () => {
  const { chain, master, warm, vine, root } = await account()
  const t0 = Date.now()
  await chain.append(await revoke(master, { root, key: vine.ref, ts: t0 + 1000 }), master)
  assert.equal(chain.state.status(vine.ref), 'revoked')
  assert.equal(chain.state.trustedAt(vine.ref, t0 + 500), true)
  assert.equal(chain.state.trustedAt(vine.ref, t0 + 1500), false)
  const later = t0 + 1000 + REENROLL_COOLDOWN + 1000
  // too soon, replayed old consent, and consent from before the revocation are all refused
  await assert.rejects(chain.append(await enroll(warm, { root, key: vine.ref, consent: await consent(vine, root), label: 'Vine', ts: t0 + 2000 }), warm), /too soon/)
  await assert.rejects(chain.append(await enroll(warm, { root, key: vine.ref, consent: await consent(vine, root), label: 'Vine', ts: later }), warm), /fresh consent/)
  const wrong = 'ab'.repeat(64)
  await assert.rejects(chain.append(await enroll(warm, { root, key: vine.ref, consent: await consent(vine, root, { after: wrong }), consentAfter: wrong, label: 'Vine', ts: later }), warm), /fresh consent/)
  // fresh proof of possession anchored to the revocation, after the cooldown: welcome back
  const after = chain.entries.findLast((e) => e.op.t === 'revoke' && e.op.key === vine.ref).op.sig
  await chain.append(await enroll(warm, { root, key: vine.ref, consent: await consent(vine, root, { after }), consentAfter: after, label: 'Vine', ts: later }), warm)
  assert.equal(chain.state.status(vine.ref), 'active')
  assert.equal(chain.state.trustedAt(vine.ref, t0 + 500), true)
  assert.equal(chain.state.trustedAt(vine.ref, t0 + 1500), false) // signed during the gap
  assert.equal(chain.state.trustedAt(vine.ref, later + 500), true)
  // compromised is forever
  await chain.append(await revoke(master, { root, key: vine.ref, reason: 'compromised', ts: later + 1000 }), master)
  const after2 = chain.entries.findLast((e) => e.op.t === 'revoke' && e.op.key === vine.ref).op.sig
  await assert.rejects(chain.append(await enroll(warm, { root, key: vine.ref, consent: await consent(vine, root, { after: after2 }), consentAfter: after2, ts: later + 2 * REENROLL_COOLDOWN }), warm), /compromised/)
})

test('a banned key stays out until the root lifts the ban; its old signatures stay valid', async () => {
  const { chain, master, warm, vine, root } = await account()
  const t0 = Date.now()
  await chain.append(await revoke(master, { root, key: vine.ref, reason: 'banned', ts: t0 + 1000 }), master)
  assert.equal(chain.state.trustedAt(vine.ref, t0 + 500), true)
  const later = t0 + 1000 + REENROLL_COOLDOWN + 1000
  const banSig = chain.entries.findLast((e) => e.op.t === 'revoke' && e.op.key === vine.ref).op.sig
  await assert.rejects(chain.append(await enroll(warm, { root, key: vine.ref, consent: await consent(vine, root, { after: banSig }), consentAfter: banSig, ts: later }), warm), /banned/)
  await assert.rejects(chain.append(await unban(warm, { root, key: vine.ref, ts: later }), warm), /only the root/)
  await chain.append(await unban(master, { root, key: vine.ref, ts: later }), master)
  assert.equal(chain.state.status(vine.ref), 'revoked')
  await chain.append(await enroll(warm, { root, key: vine.ref, consent: await consent(vine, root, { after: banSig }), consentAfter: banSig, label: 'Vine', ts: later + 10 }), warm)
  assert.equal(chain.state.status(vine.ref), 'active')
})

test('revoked writer can no longer append', async () => {
  const { chain, master, warm, root } = await account()
  await chain.append(await revoke(master, { root, key: warm.ref, reason: 'compromised' }), master)
  const k = generate()
  await assert.rejects(async () => await chain.append(await enroll(master, { root, key: k.ref, consent: await consent(k, root) }), warm), /not allowed to append/)
})

test('only self or an ancestor can revoke', async () => {
  const { chain, warm, vine, root } = await account()
  const other = generate()
  await chain.append(await enroll(warm, { root, key: other.ref, consent: await consent(other, root) }), warm)
  // a sibling can't revoke Vine
  await assert.rejects(async () => await chain.append(await revoke(other, { root, key: vine.ref }), warm), /only the key itself or an active ancestor/)
})

test('removed keys keep history; compromised keys lose it from `since`', async () => {
  const { chain, master, warm, vine, root } = await account()
  await chain.append(await revoke(warm, { root, key: vine.ref, ts: 2000 }), warm)
  assert.equal(chain.state.trustedAt(vine.ref, 1999), true)
  assert.equal(chain.state.trustedAt(vine.ref, 2000), false)

  await chain.append(await revoke(master, { root, key: warm.ref, reason: 'compromised', since: 500, ts: 3000 }), master)
  assert.equal(chain.state.trustedAt(warm.ref, 499), true)
  assert.equal(chain.state.trustedAt(warm.ref, 500), false)
})

test('tampering breaks the chain at the tampered entry', async () => {
  const { chain } = await account()
  const entries = structuredClone(chain.toJSON())
  entries[2].op.label = 'Evil'
  const r = fold(entries)
  assert.equal(r.valid, 2)
  assert.match(r.error, /entry 2/)
})

test('merge: advance, behind, and fork detection', async () => {
  const { chain, warm, root } = await account()
  const copy = new Chain(structuredClone(chain.toJSON()))
  const k = generate()
  await chain.append(await enroll(warm, { root, key: k.ref, consent: await consent(k, root) }), warm)

  assert.equal(copy.merge(chain.toJSON()).result, 'advanced')
  assert.equal(copy.state.status(k.ref), 'active')
  assert.equal(chain.merge(chain.toJSON().slice(0, 2)).result, 'behind')

  // a stolen warm key writes a different entry at the same seq
  const a = generate()
  const b = generate()
  const left = new Chain(structuredClone(chain.toJSON()))
  const right = new Chain(structuredClone(chain.toJSON()))
  await left.append(await enroll(warm, { root, key: a.ref, consent: await consent(a, root) }), warm)
  await right.append(await enroll(warm, { root, key: b.ref, consent: await consent(b, root) }), warm)
  const m = left.merge(right.toJSON())
  assert.equal(m.result, 'fork')
  assert.equal(m.seq, 4)
})

test('rejects a chain for a different root', async () => {
  const { chain } = await account()
  const other = await (await account()).chain
  assert.equal(chain.merge(other.toJSON()).result, 'rejected')
})
