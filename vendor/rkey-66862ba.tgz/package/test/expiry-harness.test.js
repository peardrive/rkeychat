import { test } from 'node:test'
import assert from 'node:assert/strict'
import { generate, consent, enroll, revoke, Chain, REENROLL_COOLDOWN } from '../src/index.js'

// expiry-harness.test.js — @kimi-zorin, rKeyChat Lab
// Prep for the exp/vouch schema (SPEC.md "Expiry and heartbeats", Not-in-v0).
// Claude's shape: enroll gains optional `exp`; trustedAt false when ts > exp,
// checked up the ancestor chain; re-enroll after a lapse gets a gap
// { from: exp, to: newEnroll.ts } by the SAME code path as a removal;
// vouch { root, key, from, to, by } closes a named gap, narrowing only.
//
// Strategy: the gap machinery EXISTS today (state.js #enroll:129-131,
// trustedAt:71-74), so the lapse scenario is pinned NOW against the
// removal path — the expiry path must produce identical trust outcomes.
// The exp/vouch tests are written and skipped; unskip when the schema lands.

async function account () {
  const master = generate('bip340')
  const warm = generate('ed25519')
  const app = generate('bip340')
  const chain = await Chain.create(master, { label: 'Guy' })
  const root = master.ref
  await chain.append(await enroll(master, { root, key: warm.ref, consent: await consent(warm, root), scope: ['bind', 'delegate'], label: 'phone' }), master)
  await chain.append(await enroll(warm, { root, key: app.ref, consent: await consent(app, root), label: 'app' }), warm)
  return { master, warm, app, chain, root }
}

function lastRevokeSig (chain, ref) {
  return chain.entries.findLast((e) => e.op.t === 'revoke' && e.op.key === ref).op.sig
}

// ---------------------------------------------------------------------------
// TODAY — the gap path that expiry must reuse. These must pass on current
// code AND keep passing unchanged once `exp` exists.
// ---------------------------------------------------------------------------

test('H1: renewal after removal does NOT bless the gap (the pinned case)', async () => {
  // enrol → "lapse" (removal stands in for expiry) → keep signing → re-enrol.
  // The lapsed signatures must stay untrusted forever. If a renewal ever
  // silently blesses the gap, a thief's week gets validated by the victim
  // renewing — this test is the alarm.
  const { chain, master, warm, app, root } = await account()
  const t0 = Date.now()

  await chain.append(await revoke(master, { root, key: app.ref, ts: t0 + 1000 }), master)
  // app "keeps signing" through the lapse: t0+1500 .. t0+5500 are gap time
  const after = lastRevokeSig(chain, app.ref)
  const renewAt = t0 + 1000 + REENROLL_COOLDOWN + 1000
  await chain.append(await enroll(warm, { root, key: app.ref, consent: await consent(app, root, { after }), consentAfter: after, label: 'app', ts: renewAt }), warm)

  assert.equal(chain.state.status(app.ref), 'active')
  assert.equal(chain.state.trustedAt(app.ref, t0 + 500), true) // before lapse
  for (const ts of [t0 + 1500, t0 + 2500, t0 + 3500, t0 + 4500, t0 + 5500]) {
    assert.equal(chain.state.trustedAt(app.ref, ts), false, `gap signature at ${ts} must stay untrusted after renewal`)
  }
  assert.equal(chain.state.trustedAt(app.ref, renewAt + 500), true) // after renewal
})

test('H2: gaps accumulate across repeated lapse/renewal cycles', async () => {
  const { chain, master, warm, app, root } = await account()
  const t0 = Date.now()
  let after
  // cycle 1
  await chain.append(await revoke(master, { root, key: app.ref, ts: t0 + 1000 }), master)
  after = lastRevokeSig(chain, app.ref)
  const r1 = t0 + 1000 + REENROLL_COOLDOWN + 1000
  await chain.append(await enroll(warm, { root, key: app.ref, consent: await consent(app, root, { after }), consentAfter: after, ts: r1 }), warm)
  // cycle 2
  await chain.append(await revoke(master, { root, key: app.ref, ts: r1 + 2000 }), master)
  after = lastRevokeSig(chain, app.ref)
  const r2 = r1 + 2000 + REENROLL_COOLDOWN + 1000
  await chain.append(await enroll(warm, { root, key: app.ref, consent: await consent(app, root, { after }), consentAfter: after, ts: r2 }), warm)

  assert.equal(chain.state.status(app.ref), 'active')
  // both gaps dead, the trusted windows between/around them alive
  assert.equal(chain.state.trustedAt(app.ref, t0 + 1500), false) // gap 1
  assert.equal(chain.state.trustedAt(app.ref, r1 + 1000), true) // between
  assert.equal(chain.state.trustedAt(app.ref, r1 + 2500), false) // gap 2
  assert.equal(chain.state.trustedAt(app.ref, r2 + 1000), true) // after
})

test('H3: a gap on an ancestor poisons the descendant during the gap', async () => {
  // warm steward "lapses": the app key it enrolled must be untrusted for the
  // same window even though the app key itself was never touched.
  const { chain, master, app, warm, root } = await account()
  const t0 = Date.now()
  await chain.append(await revoke(master, { root, key: warm.ref, ts: t0 + 1000 }), master)
  assert.equal(chain.state.status(app.ref), 'orphaned')
  // (no re-enroll here: pinning that orphaned means untrusted, not just a label)
  assert.equal(chain.state.trustedAt(app.ref, t0 + 1500), false, 'descendant of a lapsed ancestor must be untrusted during the lapse')
  assert.equal(chain.state.trustedAt(app.ref, t0 + 500), true)
})

// ---------------------------------------------------------------------------
// FUTURE — exp + vouch. Written to Claude's stated shape; skipped until the
// schema exists. Unskip, adjust the API call sites, and these become the
// acceptance tests for the feature.
// ---------------------------------------------------------------------------

test('F1: lapse by expiry behaves exactly like lapse by removal', { skip: 'exp not in schema (SPEC Not-in-v0)' }, async () => {
  const { chain, master, warm, app, root } = await account()
  const t0 = Date.now()
  // enrol app with exp = t0+2000 via warm
  // assert trustedAt(app, t0+1000) true, trustedAt(app, t0+3000) false
  // app signs through the lapse (t0+3000..t0+6000) — all must be untrusted
  // re-enrol app at t0+7000 with fresh consent
  // assert gap { from: t0+2000, to: t0+7000 } exists and every lapse ts is false
  // assert trustedAt(app, t0+7500) true
})

test('F2: ancestor expiry poisons descendants for the lapse window only', { skip: 'exp not in schema' }, async () => {
  // warm enrolled with exp; app under it. After warm.exp: app untrusted.
  // warm renewed at T2: app trusted again for ts > T2, but NOT for the
  // window (warm.exp, T2) — the ancestor gap must propagate down the chain.
})

test('F3: vouch closes a named gap — and only that gap', { skip: 'vouch op does not exist' }, async () => {
  // After H1's state: vouch { root, key: app.ref, from: t0+1000, to: renewAt, by: warm }
  // signed by warm (active, has delegate).
  // assert trustedAt inside the vouched window is now true
  // assert vouch signed by a key WITHOUT delegate is rejected
  // assert vouch cannot widen beyond the ancestor's own trusted window
  // (a vouch from a key that was itself lapsed in that window is void)
})

test('F4: vouch never resurrects compromised', { skip: 'vouch op does not exist' }, async () => {
  // revoke(app, reason: 'compromised') → any vouch covering that window
  // must be rejected. compromised is forever; vouch only ever addresses
  // lapse gaps, never compromise windows.
})
