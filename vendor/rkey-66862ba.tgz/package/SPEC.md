# rKey v0

Keys sign for keys, revocably. An account is a **root key** plus a tree of keys bound under it. Every binding is signed in both directions. Any key in the tree can be cut off, and cutting a key cuts its whole branch.

## Keys

A key is named by its **ref**, `<suite>:<hex pubkey>`:

| suite | used by | signature |
|---|---|---|
| `ed25519` | Pear / pearcore / Hyperswarm | Ed25519 |
| `bip340` | Nostr | Schnorr over secp256k1 (x-only keys) |

Signatures are always over `sha256("rkey/v0/<domain>\n" || canonical_json(body))`. The domains are `consent`, `op`, `entry` and `entry-id`. Domain separation means an rKey statement can never double as a Nostr event, a Bitcoin message or another rKey statement type.

Canonical JSON sorts object keys, drops `undefined` fields, adds no whitespace and allows only safe integers.

## Ops (self-authenticating statements)

Each op is signed by the key whose authority it uses (`by`), so any holder of the chain can fold it in. The writer never needs to be the key that authorized the change.

- **consent**: the subkey's half of the binding. `sign(key, consent{root, key})`. It deliberately omits the parent, so the same consent still works after the key is re-adopted higher in the tree. Without it, nobody can put a key into their account, e.g. a pasted brother's key.
- **enroll** `{t, root, key, parent, scope, label, consent, ts, by=parent}`:
  - The parent must be active and hold `delegate`.
  - The scope must be a subset of the parent's effective scope. Only the root holds `*`.
- **revoke** `{t, root, key, reason, since?, ts, by}`:
  - `by` is either the key itself (self-revoke, i.e. "remove this app from my account") or an active ancestor.
  - `reason` is `removed` or `compromised`.

## Chain (ordering)

Entries have the form `{v:0, root, seq, prev, ts, op, writer, sig}`:
- Entry 0 wraps `genesis`, and both the entry and the op are signed by the root.
- `prev` = `entry-id` of the previous entry.
- The writer must be the root or an active key with `delegate`. In practice that's the warm steward.
- A writer can delay or withhold ops, but it can't forge them.
- Verification stops at the first bad entry.

**Merge**: if one chain is a prefix of the other, the longer one wins. Two valid entries at the same `seq` are a **fork**, which is proof that a writer key equivocated. A fork is surfaced to the user and never resolved automatically in v0.

**Pending ops**: a verifier may apply valid ops it has seen but the chain hasn't absorbed yet (`chain.view(pending)`). That's how a self-revoke takes effect immediately while the steward is offline.

## Status and trust

- A key is **active** when it and every one of its ancestors are unrevoked. Status is computed from the tree, not stored.
- Revoking a key **orphans** its whole subtree.
- Enrolling an orphan under a live ancestor **re-adopts** it, along with everything beneath it.
- Revocation reasons: `removed` (logged out, kicked), `compromised`, `banned`.
- A key revoked as `removed` may be enrolled again after a cooldown (one hour), with a **fresh consent anchored to the revocation** (`consent(key, root, { after: <revoke op sig> })`, carried as `consentAfter` on the enroll op; no clocks involved). Its signatures from the gap are untrusted. This lets a person sign an app back in, or an owner re-invite someone they removed, without a replayed record or a lost key getting back in.
- A key revoked as `compromised` can never be re-enrolled: make a fresh key.
- A key revoked as `banned` keeps its old signatures valid (it was not a compromise) but stays out until the root appends an **unban** op; after that it is treated as `removed` (cooldown and fresh consent apply). Only the root can unban, so no other admin can quietly readmit a banned key.
- `trustedAt(key, ts)`:
  - A `removed` key keeps its signatures from before `ts`.
  - A `compromised` key loses everything from `since` onward. `since` defaults to 0, which means all of it.
  - Timestamps are self-asserted in v0, so anchoring is a later addition.

## Scopes

Core interprets only `delegate`. Apps define their own, e.g. `chat`. A verifier grants nothing for a scope it doesn't understand.

## Not in v0

- Root rotation or succession (pre-committed successor, or a FROST root).
- Expiry and heartbeats.
- Timestamp anchoring.
- Nostr event mirroring.
- Marmot/MLS credential proofs.
- Selective disclosure (private bindings).
