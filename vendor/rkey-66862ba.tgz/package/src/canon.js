// Canonical JSON and domain-separated digests. Every signature in rKey is over
// sha256("rkey/v0/<domain>\n" || canonical(body)), so a statement signed for one
// purpose can never be replayed as another (or as a foreign-protocol message).

import { sha256 } from '@noble/hashes/sha2.js'
import { bytesToHex, utf8ToBytes } from '@noble/hashes/utils.js'

export function canonical (value) {
  if (value === null) return 'null'
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`
  switch (typeof value) {
    case 'string':
    case 'boolean':
      return JSON.stringify(value)
    case 'number':
      if (!Number.isSafeInteger(value)) throw new Error('only safe integers are allowed in signed statements')
      return String(value)
    case 'object': {
      const keys = Object.keys(value).filter((k) => value[k] !== undefined).sort()
      return `{${keys.map((k) => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`
    }
    default:
      throw new Error(`cannot canonicalize ${typeof value}`)
  }
}

export function digest (domain, body) {
  return sha256(utf8ToBytes(`rkey/v0/${domain}\n${canonical(body)}`))
}

export function hashHex (domain, body) {
  return bytesToHex(digest(domain, body))
}

export function without (obj, field) {
  const { [field]: _, ...rest } = obj
  return rest
}
