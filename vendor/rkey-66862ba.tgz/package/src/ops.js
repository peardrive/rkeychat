// Ops are standalone signed statements. Each carries its own authority (the
// signature of the key that is allowed to make it), so any holder of the chain
// can fold it in: a device can hand its self-revocation to the steward, and a
// delegating app key can hand an enrollment upward, without either needing to
// write to the chain itself.

import { bytesToHex } from '@noble/hashes/utils.js'
import { digest, without } from './canon.js'
import { verifySig } from './keys.js'

// removed: may come back later (fresh consent, after a cooldown). compromised: never.
// banned: kept out by the tree's owner until an explicit unban; old signatures stay valid.
export const REASONS = ['removed', 'compromised', 'banned']

// The subkey's half of the two-way binding: "I consent to belong to <root>".
// Deliberately excludes the parent so the same consent survives re-adoption
// higher up the tree.
// With `after` (the signature of the revoke op being undone), the consent is a
// fresh proof of possession anchored to that revocation: it can't have been
// signed before the revocation existed, and no clock is involved.
export async function consent (keySigner, root, { after } = {}) {
  return bytesToHex(await keySigner.sign(digest('consent', after ? { root, key: keySigner.ref, after } : { root, key: keySigner.ref })))
}

export function verifyConsent (root, key, sig, after) {
  return typeof sig === 'string' && verifySig(key, sig, digest('consent', after ? { root, key, after } : { root, key }))
}

async function signOp (signer, body) {
  const op = { ...body, by: signer.ref }
  return { ...op, sig: bytesToHex(await signer.sign(digest('op', op))) }
}

export function verifyOpSig (op) {
  return !!op && typeof op.sig === 'string' && verifySig(op.by, op.sig, digest('op', without(op, 'sig')))
}

export async function genesis (rootSigner, { ts = Date.now(), label } = {}) {
  return signOp(rootSigner, { t: 'genesis', root: rootSigner.ref, label, ts })
}

export async function enroll (parentSigner, { root, key, consent, consentAfter, scope = ['bind'], label, ts = Date.now() }) {
  return signOp(parentSigner, { t: 'enroll', root, key, parent: parentSigner.ref, scope, label, consent, consentAfter, ts })
}

// by === key is a self-revocation ("remove this app from my account").
// For 'compromised', signatures from the key at or after `since` are
// distrusted; since defaults to 0, i.e. distrust everything it ever signed.
export async function revoke (bySigner, { root, key, reason = 'removed', since, ts = Date.now() }) {
  if (!REASONS.includes(reason)) throw new Error(`unknown revoke reason: ${reason}`)
  if (reason === 'compromised' && since === undefined) since = 0
  return signOp(bySigner, { t: 'revoke', root, key, reason, since, ts })
}

// Only the root lifts a ban. The key is still revoked afterwards; it comes
// back through a fresh enrollment like any removed key.
export async function unban (rootSigner, { root, key, ts = Date.now() }) {
  return signOp(rootSigner, { t: 'unban', root, key, ts })
}
