// The account chain: an append-only, hash-linked list of entries, each wrapping
// one op. Ops carry authority; entries carry order. An entry may be written by
// the root or any active key with 'delegate' (in practice the warm steward).
// A writer can delay or withhold ops, but can't forge them.

import { bytesToHex } from '@noble/hashes/utils.js'
import { digest, hashHex, without } from './canon.js'
import { verifySig } from './keys.js'
import { verifyOpSig, genesis as genesisOp } from './ops.js'
import { KeyState, DELEGATE } from './state.js'

export const entryId = (entry) => hashHex('entry-id', entry)

async function signEntry (writer, body) {
  const e = { v: 0, ...body, writer: writer.ref }
  return { ...e, sig: bytesToHex(await writer.sign(digest('entry', e))) }
}

function checkEntry (state, entry, seq, prev) {
  if (entry?.v !== 0) throw new Error('unsupported entry version')
  if (entry.root !== state.root) throw new Error('entry is for a different root')
  if (entry.seq !== seq) throw new Error(`expected seq ${seq}`)
  if (entry.prev !== prev) throw new Error('prev does not link to the previous entry')
  if (!verifySig(entry.writer, entry.sig, digest('entry', without(entry, 'sig')))) throw new Error('bad entry signature')
  if (!state.can(entry.writer, DELEGATE)) throw new Error('writer is not allowed to append')
}

// Fold entries into a KeyState. Stops at the first invalid entry: everything
// after it links through it, so nothing after it can be trusted either.
export function fold (entries) {
  const g = entries[0]
  if (!g || g.op?.t !== 'genesis' || g.seq !== 0 || g.prev !== null) {
    return { state: null, valid: 0, error: 'missing genesis' }
  }
  const root = g.op.root
  if (g.root !== root || g.writer !== root || g.op.by !== root || !verifyOpSig(g.op)) {
    return { state: null, valid: 0, error: 'bad genesis' }
  }
  const state = new KeyState(root)
  try {
    checkEntry(state, g, 0, null)
  } catch (err) {
    return { state: null, valid: 0, error: err.message }
  }
  let prev = entryId(g)
  for (let i = 1; i < entries.length; i++) {
    try {
      checkEntry(state, entries[i], i, prev)
      state.apply(entries[i].op)
    } catch (err) {
      return { state, valid: i, head: prev, error: `entry ${i}: ${err.message}` }
    }
    prev = entryId(entries[i])
  }
  return { state, valid: entries.length, head: prev, error: null }
}

export class Chain {
  constructor (entries = []) {
    const r = fold(entries)
    if (r.error) throw new Error(`invalid chain: ${r.error}`)
    this.entries = [...entries]
    this.state = r.state
    this.head = r.head
  }

  static async create (rootSigner, opts) {
    const op = await genesisOp(rootSigner, opts)
    const entry = await signEntry(rootSigner, { root: op.root, seq: 0, prev: null, ts: op.ts, op })
    return new Chain([entry])
  }

  get root () { return this.state.root }
  get seq () { return this.entries.length - 1 }

  // Validates the op against a copy of the state first, so a bad op never
  // produces a signed entry. Appends are serialized: the signer may be slow
  // (a card tap, a phone relay), and the chain head must not move under it.
  append (op, writer, opts) {
    this.queue = (this.queue ?? Promise.resolve()).then(() => this.#append(op, writer, opts), () => this.#append(op, writer, opts))
    return this.queue
  }

  async #append (op, writer, { ts = Date.now() } = {}) {
    const next = this.state.clone()
    next.apply(op)
    const entry = await signEntry(writer, { root: this.root, seq: this.entries.length, prev: this.head, ts, op })
    checkEntry(this.state, entry, this.entries.length, this.head)
    this.entries.push(entry)
    this.state = next
    this.head = entryId(entry)
    return entry
  }

  // Current view plus ops that haven't been folded into the chain yet. Lets a
  // verifier honor a device's self-revocation (or a fresh enrollment) the
  // moment it sees it, before the steward is next online.
  view (pending = []) {
    const s = this.state.clone()
    const applied = []
    for (const op of pending) {
      try { s.apply(op); applied.push(op) } catch {}
    }
    return { state: s, applied }
  }

  // Reconcile with a copy received from a peer. Returns what happened; only
  // adopts the remote copy when it strictly extends ours.
  merge (remoteEntries) {
    const r = fold(remoteEntries)
    if (!r.state || r.state.root !== this.root) return { result: 'rejected', error: r.error ?? 'different root' }
    const remote = remoteEntries.slice(0, r.valid)
    const common = Math.min(remote.length, this.entries.length)
    for (let i = 0; i < common; i++) {
      if (entryId(remote[i]) !== entryId(this.entries[i])) {
        return { result: 'fork', seq: i, ours: this.entries[i], theirs: remote[i] }
      }
    }
    if (remote.length <= this.entries.length) return { result: remote.length < this.entries.length ? 'behind' : 'same' }
    const adopted = new Chain(remote)
    this.entries = adopted.entries
    this.state = adopted.state
    this.head = adopted.head
    return { result: 'advanced', seq: this.seq, partial: r.error ?? null }
  }

  toJSON () { return this.entries }
}
