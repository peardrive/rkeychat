// Key suites and signers. A key is referred to everywhere by its "ref":
// "<suite>:<hex public key>", e.g. "ed25519:ab12…" (Pear/pearcore keys) or
// "bip340:cd34…" (Nostr keys, x-only secp256k1 Schnorr).

import { ed25519 } from '@noble/curves/ed25519.js'
import { schnorr } from '@noble/curves/secp256k1.js'
import { bytesToHex, hexToBytes } from '@noble/hashes/utils.js'

const SUITES = {
  ed25519: {
    randomSecretKey: () => ed25519.utils.randomSecretKey(),
    getPublicKey: (sk) => ed25519.getPublicKey(sk),
    sign: (msg, sk) => ed25519.sign(msg, sk),
    verify: (sig, msg, pk) => ed25519.verify(sig, msg, pk)
  },
  bip340: {
    randomSecretKey: () => schnorr.utils.randomSecretKey(),
    getPublicKey: (sk) => schnorr.getPublicKey(sk),
    sign: (msg, sk) => schnorr.sign(msg, sk),
    verify: (sig, msg, pk) => schnorr.verify(sig, msg, pk)
  }
}

export const suites = Object.keys(SUITES)

export function parseRef (ref) {
  if (typeof ref !== 'string') throw new Error('key ref must be a string')
  const i = ref.indexOf(':')
  const suite = ref.slice(0, i)
  const hex = ref.slice(i + 1)
  if (i < 0 || !SUITES[suite]) throw new Error(`unknown key suite in ref: ${ref}`)
  if (!/^[0-9a-f]{64}$/.test(hex)) throw new Error(`malformed public key in ref: ${ref}`)
  return { suite, publicKey: hexToBytes(hex) }
}

export function toRef (suite, publicKey) {
  if (!SUITES[suite]) throw new Error(`unknown key suite: ${suite}`)
  return `${suite}:${bytesToHex(publicKey)}`
}

// A signer is anything with { ref, sign(bytes) -> Uint8Array | Promise<Uint8Array> }.
// rKey always awaits it, so an NFC card, a phone relaying a card tap, or a
// remote signer app can stand in for a local key.
export function signerFromSecret (suite, secretKey) {
  const s = SUITES[suite]
  if (!s) throw new Error(`unknown key suite: ${suite}`)
  const sk = typeof secretKey === 'string' ? hexToBytes(secretKey) : secretKey
  const ref = toRef(suite, s.getPublicKey(sk))
  return { ref, sign: (msg) => s.sign(msg, sk) }
}

export function generate (suite = 'ed25519') {
  const s = SUITES[suite]
  if (!s) throw new Error(`unknown key suite: ${suite}`)
  const secretKey = s.randomSecretKey()
  return { ...signerFromSecret(suite, secretKey), secretKey: bytesToHex(secretKey) }
}

export function verifySig (ref, sigHex, msg) {
  try {
    const { suite, publicKey } = parseRef(ref)
    return SUITES[suite].verify(hexToBytes(sigHex), msg, publicKey)
  } catch {
    return false
  }
}
