// The key tree an account's chain folds into, and the rules for applying ops.
//
// Status is computed, not stored: a key is effectively active only while it
// and every ancestor are unrevoked. Revoking a key therefore orphans its whole
// subtree, and re-enrolling an orphan under a live ancestor ("re-adopt
// upward") brings it — and everything beneath it — back.

import { verifyConsent, verifyOpSig } from './ops.js'

export const ALL = '*'
// Core only interprets 'delegate'. Apps may define and check their own scopes;
// a verifier that doesn't know a scope grants nothing for it.
export const DELEGATE = 'delegate'
export const REENROLL_COOLDOWN = 60 * 60_000 // a removed key stays out at least this long

export class KeyState {
  constructor (root) {
    this.root = root
    this.nodes = new Map([[root, { ref: root, parent: null, scope: [ALL], label: undefined, revoked: null, ts: 0 }]])
  }

  clone () {
    const s = new KeyState(this.root)
    s.nodes = new Map([...this.nodes].map(([k, v]) => [k, { ...v }]))
    return s
  }

  get (ref) { return this.nodes.get(ref) }

  isActive (ref) {
    for (let n = this.nodes.get(ref); n; n = this.nodes.get(n.parent)) {
      if (n.revoked) return false
      if (n.parent === null) return true
    }
    return false
  }

  status (ref) {
    const n = this.nodes.get(ref)
    if (!n) return 'unknown'
    if (n.revoked) return n.revoked.reason === 'compromised' ? 'compromised' : 'revoked'
    return this.isActive(ref) ? 'active' : 'orphaned'
  }

  ancestors (ref) {
    const out = []
    for (let n = this.nodes.get(this.nodes.get(ref)?.parent); n; n = this.nodes.get(n.parent)) out.push(n.ref)
    return out
  }

  isAncestor (a, b) { return this.ancestors(b).includes(a) }

  scopeOf (ref) {
    if (!this.nodes.has(ref)) return []
    let scope = [ALL]
    for (const n of [ref, ...this.ancestors(ref)].map((r) => this.nodes.get(r))) {
      if (n.scope.includes(ALL)) continue
      scope = scope.includes(ALL) ? [...n.scope] : scope.filter((s) => n.scope.includes(s))
    }
    return scope
  }

  can (ref, scope) {
    if (!this.isActive(ref)) return false
    const s = this.scopeOf(ref)
    return s.includes(ALL) || s.includes(scope)
  }

  // Would a signature this key made at time `ts` be trusted? Keys removed
  // normally keep their history; compromised keys lose it from `since`.
  trustedAt (ref, ts) {
    if (!this.nodes.has(ref)) return false
    for (const n of [ref, ...this.ancestors(ref)].map((r) => this.nodes.get(r))) {
      if ((n.gaps ?? []).some((g) => ts >= g.from && ts < g.to)) return false
      const r = n.revoked
      if (!r) continue
      if (r.reason === 'compromised' ? ts >= r.since : ts >= r.ts) return false
    }
    return true
  }

  members () {
    return [...this.nodes.values()].map((n) => ({
      ref: n.ref,
      parent: n.parent,
      label: n.label,
      scope: this.scopeOf(n.ref),
      status: this.status(n.ref),
      reason: n.revoked?.reason,
      // when this key was enrolled, and when it was cut off: enough for an app to
      // show who joined and who left, and when, without reading the chain itself
      ts: n.ts,
      revokedAt: n.revoked?.ts,
      depth: this.ancestors(n.ref).length
    }))
  }

  // Throws with a reason if the op isn't valid against the current state.
  apply (op) {
    if (!verifyOpSig(op)) throw new Error('bad op signature')
    if (op.root !== this.root) throw new Error('op is for a different root')
    if (op.t === 'enroll') return this.#enroll(op)
    if (op.t === 'revoke') return this.#revoke(op)
    if (op.t === 'unban') return this.#unban(op)
    throw new Error(`unexpected op: ${op.t}`)
  }

  #enroll (op) {
    const { key, parent, scope } = op
    if (op.by !== parent) throw new Error('enroll must be signed by the parent')
    if (key === this.root) throw new Error('cannot enroll the root')
    if (!this.can(parent, DELEGATE)) throw new Error('parent cannot delegate')
    if (!verifyConsent(this.root, key, op.consent, op.consentAfter)) throw new Error('missing or bad consent from the enrolled key')
    if (!Array.isArray(scope) || scope.some((s) => typeof s !== 'string')) throw new Error('bad scope')
    if (scope.includes(ALL)) throw new Error('only the root holds *')
    const ps = this.scopeOf(parent)
    if (!ps.includes(ALL) && scope.some((s) => !ps.includes(s))) throw new Error('scope exceeds parent')

    const existing = this.nodes.get(key)
    let gaps = []
    if (existing) {
      // a key revoked as 'removed' (logged out, kicked) may be brought back;
      // 'compromised' is final. Its signatures from the gap stay untrusted.
      if (existing.revoked?.reason === 'compromised') throw new Error('key was revoked as compromised; enroll a fresh key instead')
      if (existing.revoked?.reason === 'banned') throw new Error('key is banned; the root must lift the ban first')
      if (existing.revoked) {
        if (op.ts < existing.revoked.ts + REENROLL_COOLDOWN) throw new Error('too soon: a removed key can come back after the cooldown')
        // fresh proof of possession, anchored to the revocation it undoes (no clocks)
        if (op.consentAfter !== existing.revoked.sig) throw new Error('re-enrollment needs a fresh consent that references the revocation')
      }
      if (this.isActive(key)) throw new Error('key is already enrolled')
      if (parent === key || this.isAncestor(key, parent)) throw new Error('cannot adopt a key under its own subtree')
      gaps = [...(existing.gaps ?? []), ...(existing.revoked ? [{ from: existing.revoked.ts, to: op.ts }] : [])]
    }
    this.nodes.set(key, { ref: key, parent, scope: [...scope], label: op.label, revoked: null, ts: op.ts, gaps })
  }

  #revoke (op) {
    const { key, by } = op
    const n = this.nodes.get(key)
    if (!n) throw new Error('unknown key')
    if (key === this.root) throw new Error('the root cannot be revoked')
    if (n.revoked) throw new Error('already revoked')
    const self = by === key
    if (!self && !(this.isActive(by) && this.isAncestor(by, key))) throw new Error('only the key itself or an active ancestor can revoke')
    n.revoked = { reason: op.reason, since: op.since, ts: op.ts, by, sig: op.sig }
  }

  #unban (op) {
    const n = this.nodes.get(op.key)
    if (!n) throw new Error('unknown key')
    if (op.by !== this.root) throw new Error('only the root lifts a ban')
    if (n.revoked?.reason !== 'banned') throw new Error('key is not banned')
    n.revoked = { ...n.revoked, reason: 'removed', ts: n.revoked.ts, unbanned: op.ts }
  }
}
